// import logo from "./logo.svg";
// import './App.css';
import React, { Component } from "react";

function Loading() {

  return  <div class="loader"></div>
}

export default Loading;
